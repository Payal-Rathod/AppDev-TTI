﻿using System;
namespace HomeBudgetDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
